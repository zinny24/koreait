create table member(
id number(6) not null,
userid varchar2(20) not null,
username varchar2(10) not null,
userpwd varchar2(20) not null,
regdate date,
primary key(id)
);

-- member_seq.nextval
create sequence member_seq 
start with 100001 increment by 1 nocycle;

INSERT INTO member VALUES(member_seq.nextval, 'koreait', '홍길동', '1234', '20231214');

SELECT * FROM member;

commit;








