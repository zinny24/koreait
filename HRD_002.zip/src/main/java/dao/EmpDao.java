package dao;

import java.util.List;

import dto.Employee;

public class EmpDao {
	
	//입력
	public void insertEmployee(Employee emp) {
		
	}		
	
	//수정
	public void updateEmployee(Employee emp) {
		
		
	}
	
	//삭제
	public void deleteEmployee(int emp_id) {
		
	}
	
	//1명 출력
	public Employee getEmployeeOne(int emp_id) {
			
		return null;		
	}
	
	//전체 출력
	public List<Employee> getEmployeeAll() {
		
		return null;
	}
	
}








