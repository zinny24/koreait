-- 회원정보 member_tbl_02
create table member_tbl_02(
custno number(6),
custname varchar2(20),
phone char(13),
address varchar2(100),
joindate date,
grade char(1),
city char(2),
primary key(custno)
);

INSERT INTO member_tbl_02 VALUES(100001, '김행복', '010-1111-2222', '서울 동대문구 휘경1동', '20151202', 'A', '01');

SELECT MAX(custno) + 1 AS custno FROM member_tbl_02;

-- 상품 money_tbl_02
CREATE TABLE money_tbl_02(
custno number(6),
saleno number(8),
pcost number,
amount number,
price number,
pcode varchar2(5),
sdate date,
primary key(custno, saleno)
);

INSERT INTO money_tbl_02 VALUES(100001, 20160001, 500, 5, 2500, 'A001', '20160101');

set linesize 1000;

select * from member_tbl_02;

column address format a100;
select * from member_tbl_02;

commit;


SELECT MAX(custno) FROM member_tbl_02;

SELECT MAX(custno)+1 FROM member_tbl_02;

NVL(값, 100001)

SELECT NVL(MAX(custno)+1, 100001) FROM member_tbl_02;















