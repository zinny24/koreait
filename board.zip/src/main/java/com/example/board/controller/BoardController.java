package com.example.board.controller;


import com.example.board.dto.BoardDto;
import com.example.board.mappers.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.UUID;

@Controller
public class BoardController {

    @Autowired
    BoardMapper boardMapper;

    @Value("${fileDir}")
    String fileDir;

    @GetMapping("/board/list")
    public String getList() {
        return "board/list";
    }

    @GetMapping("/board/write")
    public String getWrite() {
        return "board/write";
    }

    @PostMapping("/board/write")
    public String setWrite(@ModelAttribute BoardDto boardDto,
                           @RequestParam("file") MultipartFile mf) throws IOException {

        if( boardDto != null ) {
            String folderName = new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis());
            File makeFolder = new File(fileDir + folderName);

            if( !makeFolder.exists() ) {
                makeFolder.mkdir();
            }

            String orgName = mf.getOriginalFilename();
            String ext = orgName.substring(orgName.lastIndexOf("."));
            String uuid = UUID.randomUUID().toString();
            String saveFileName = uuid + ext;
            String savedFilePathName = fileDir + folderName + "/" + saveFileName;

            /* boardDto => db */
            boardDto.setOrgName(orgName);
            boardDto.setSavedFileName(saveFileName);
            boardDto.setSavedFilePathName(savedFilePathName);
            boardDto.setSavedFileSize(mf.getSize());
            boardDto.setFolderName(folderName);

            int maxGrp = boardMapper.getMaxGrp();
            boardDto.setGrp(maxGrp);
            boardMapper.setWrite(boardDto);

            /* 파일 업로드 쓰기 */
            mf.transferTo( new File(savedFilePathName) );
        }



        return "redirect:/board/list";
    }

}
