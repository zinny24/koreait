package com.example.board.mappers;

import com.example.board.dto.BoardDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BoardMapper {

    @Select("SELECT ifnull( max(grp) + 1, 1 ) AS maxGrp FROM board")
    int getMaxGrp();

    @Insert("INSERT INTO board VALUES(null, " +
            "#{subject}, #{writer}, #{content}, 0, now(), " +
            "#{orgName}, #{savedFileName}, #{savedFilePathName}, #{savedFileSize}, " +
            "#{folderName}, #{grp}, 1, 1)")
    void setWrite(BoardDto boardDto);



}







