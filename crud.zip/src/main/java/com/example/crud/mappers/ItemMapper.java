package com.example.crud.mappers;

import com.example.crud.dto.ItemsDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ItemMapper {

    @Insert("INSERT INTO items VALUES(null, #{itemName}, #{itemPrice})")
    public void setAddItem(ItemsDto itemsDto);

}
