package com.example.jpaEx.controller;

import com.example.jpaEx.entity.Item;
import com.example.jpaEx.repository.ItemRepository;
import jakarta.persistence.OrderBy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class JpaController {

    @Autowired
    private ItemRepository itemRepository;

    @GetMapping("/items")
    public String getItems(Model model) {
        model.addAttribute("items", itemRepository.findAll());
        return "shop/items";
    }

    @GetMapping("/add")
    public String getItem() {
        return "shop/add";
    }

    @PostMapping("/add")
    public String setItem(@ModelAttribute Item item) {
        itemRepository.save(item);

        return "redirect:/items";
    }

}
