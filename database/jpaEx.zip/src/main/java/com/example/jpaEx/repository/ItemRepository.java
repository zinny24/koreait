package com.example.jpaEx.repository;

import com.example.jpaEx.entity.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemRepository extends JpaRepository<Item, Integer> { //객체(dto,entity)이름과 primary key 객체타입 지정

}
