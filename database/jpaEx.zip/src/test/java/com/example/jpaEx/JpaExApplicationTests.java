package com.example.jpaEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaExApplicationTests {

	@Test
	void contextLoads() {
	}

}
