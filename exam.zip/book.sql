create table smallCategory (
    smallCode varchar2(3) not null,
    smallName varchar2(20) not null,
    bigCode varchar2(3) not null,
    primary key(smallCode)
);

INSERT INTO smallCategory VALUES('100', '소설/시','100');
INSERT INTO smallCategory VALUES('200', '인문','100');
INSERT INTO smallCategory VALUES('300', '예술','100');
INSERT INTO smallCategory VALUES('400', '사회','100');
INSERT INTO smallCategory VALUES('500', 'IT모바일','100');

INSERT INTO smallCategory VALUES('600','ELT사전','200');
INSERT INTO smallCategory VALUES('700','문학/소설','200');
INSERT INTO smallCategory VALUES('800','경제/경영','200');

commit;

create table books (
book_id number(3) not null,
book_name varchar2(100) not null,
book_price number(10) default 0,
book_stock number(5) default 0,
book_discount number(3) default 0.0,
book_type varchar2(6) default 'NORMAL',
book_content nvarchar2(1000) not null,
book_regdate date,
smallCode varchar2(3) not null,
primary key(book_id),
foreign key(smallCode) references smallCategory(smallCode) ON DELETE CASCADE
);

INSERT INTO books VALUES(101, '이것이 자바다', 25000, 10, 10, 'NEW', '이것이 자바다 도서는..', sysdate, '500');
INSERT INTO books VALUES(102, '자바의 정석', 30000, 5, 20, 'NORMAL', '자바의 정석 도서는', sysdate, '500');
INSERT INTO books VALUES(103, '명견만리', 12000, 5, 20, 'BEST', 'KBS 명견만리 제작진이...', sysdate, '200');
INSERT INTO books VALUES(104, '콜린스,코빌드 영어 사전', 99000, 5, 10, 'BEST', '콜린스 코빌드 영어 사전은 옥스포드..', sysdate, '600');
INSERT INTO books VALUES(105, '황순원의 소나기', 1000, 100, 10, 'NORMAL', '교육부 권장도서, 황순원의 소나기', sysdate, '700');

commit;
