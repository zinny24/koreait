package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import dto.Book;

public class BookDao {
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;	

	public int getStartNum() throws SQLException {
		
		conn = DBConnect.getConnection();
		String sql = "SELECT MAX(book_id) as book_id FROM books";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		int startNum = 0;
		if( rs.next() ) {
			startNum = rs.getInt("book_id") + 1;	
		}			
		
		return startNum;
		
	}
	
	public int setBook(Book book) throws SQLException {
		conn = DBConnect.getConnection();
		String sql = "INSERT INTO books VALUES(?, ?, ?, ?, ?, ?, ?, sysdate, ?)";
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, book.getBook_id());
		pstmt.setString(2, book.getBook_name());
		pstmt.setInt(3, book.getBook_price());
		pstmt.setInt(4, book.getBook_stock());
		pstmt.setInt(5, book.getBook_discount());
		pstmt.setString(6, book.getBook_type());
		pstmt.setString(7, book.getBook_content());
		pstmt.setString(8, book.getSmallCode());
		
		int result = pstmt.executeUpdate();
		
		return result;
		
	}
	
	public List<Book> getBooks() throws SQLException {
		
		conn = DBConnect.getConnection();
		List<Book> bList = new ArrayList<>();
		
		String sql = "SELECT * FROM books ORDER BY book_id DESC";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		if( rs.next() ) {
			
			do {
				
				Book book = new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_stock(rs.getInt("book_stock"));
				book.setBook_discount(rs.getInt("book_discount"));
				book.setBook_type(rs.getString("book_type"));
				book.setBook_content(rs.getString("book_content"));
				book.setBook_regdate(rs.getDate("book_regdate").toLocalDate());
				bList.add(book);
			
			}while(rs.next());			
		}
		
		return bList;
		
	}
	
	public int deleteBook(int book_id) throws SQLException {
		conn = DBConnect.getConnection();
		String sql = "DELETE FROM books WHERE book_id = ?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		int result = pstmt.executeUpdate();
		
		return result;
	}
	
	
	public List<Book> searchBook(String search_word) throws SQLException {
		
		conn = DBConnect.getConnection();
		List<Book> bList = new ArrayList<>();
		String sql = "SELECT * FROM smallCategory S INNER JOIN books B ON B.smallCode = S.smallCode WHERE B.book_name like '%"+search_word+"%'";
		
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		if( rs.next() ) {
			
			do {
				
				Book book = new Book();
				book.setBook_id(rs.getInt("book_id"));
				book.setBook_name(rs.getString("book_name"));
				book.setBook_price(rs.getInt("book_price"));
				book.setBook_stock(rs.getInt("book_stock"));
				book.setBook_discount(rs.getInt("book_discount"));
				book.setBook_type(rs.getString("book_type"));
				book.setBook_content(rs.getString("book_content"));
				book.setBook_regdate(rs.getDate("book_regdate").toLocalDate());
				book.setSmallName(rs.getString("smallName"));
				bList.add(book);
			
			}while(rs.next());			
		}
		
		return bList;
		
	}
}










