package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.DBConnect;
import dto.SmallCategory;

public class SmallDao {
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	List<SmallCategory> sList = new ArrayList<SmallCategory>();

	public List<SmallCategory> getSmallCategory() throws SQLException {
		
		conn = DBConnect.getConnection();
		String sql = "SELECT * FROM smallCategory";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		if( rs.next() ) {
			do {
				SmallCategory sc = new SmallCategory();
				sc.setSmallCode(rs.getString("smallCode"));
				sc.setSmallName(rs.getString("smallName"));
				sList.add(sc);
				
			}while(rs.next());
		}
			
		return sList;		
		
	}
}
