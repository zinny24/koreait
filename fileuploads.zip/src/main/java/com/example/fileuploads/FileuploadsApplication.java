package com.example.fileuploads;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileuploadsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileuploadsApplication.class, args);
	}

}
