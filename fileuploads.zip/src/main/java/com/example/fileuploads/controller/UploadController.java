package com.example.fileuploads.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.UUID;

@Controller
public class UploadController {

    @Value("${fileDir}")
    String fileDir;

    @GetMapping("/upload")
    public String getUpload() {
        return "upload/uploadForm";
    }

    @PostMapping("/upload")
    public String setUpload(
            Model model,
            @RequestParam("file") MultipartFile file) throws IOException {
        File folderName = new File(fileDir + new SimpleDateFormat("yyyyMMdd")
                .format(System.currentTimeMillis()));

        if( !folderName.exists() ) {
            folderName.mkdir();
        }

        String oriName = file.getOriginalFilename();
        String uuid = UUID.randomUUID().toString();
        String ext = oriName.substring( oriName.lastIndexOf(".") );

        String savedFileName = uuid + ext;
        String savedPathFileName = folderName + "/" + savedFileName;

        file.transferTo( new File(savedPathFileName) );


        model.addAttribute("savedFileName", savedFileName);
        model.addAttribute("savedPathFileName", savedPathFileName);

        return "upload/uploadView";
    }

    @GetMapping("/uploadView")
    public String getUploadView() {
        return "upload/uploadView";
    }

}
