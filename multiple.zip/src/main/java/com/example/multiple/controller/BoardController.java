package com.example.multiple.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class BoardController {

    @GetMapping("/board/boardList")
    public String getBoardList(@RequestParam String configCode, Model model) {
        model.addAttribute("configCode", configCode);
        return "board/boardList";
    }

    @GetMapping("/board/boardWrite")
    public String getBoardWrite(@RequestParam String configCode, Model model) {
        model.addAttribute("configCode", configCode);
        return "board/boardWrite";
    }

}
