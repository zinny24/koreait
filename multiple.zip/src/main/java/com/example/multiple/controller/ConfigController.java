package com.example.multiple.controller;

import com.example.multiple.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

@Controller
public class ConfigController {

    @Autowired
    ConfigService configService;

    @GetMapping("/config/configList")
    public String getConfigList() {
        return "config/configList";
    }

    @GetMapping("/config/configWrite")
    public String getConfigWrite() {
        return "config/configWrite";
    }

    @GetMapping("/config/checkConfigCode")
    @ResponseBody
    public Map<String, Object> getCheckConfigCode(@RequestParam String configCode) {
        int checkCode = configService.getCheckConfigCode(configCode);

        return Map.of("checkCode", checkCode);
    }

}
