package com.example.multiple.mappers;

import com.example.multiple.dto.BoardDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface BoardMapper {

    @Select("SELECT IFNULL( MAX(grp) + 1,  1) FROM board_${configCode}")
    public int getGrpMaxCnt(String configCode);

    @Insert("INSERT INTO board_${configCode} VALUES(null, #{subject}, #{writer}, #{content}, 0, now(), #{grp}, 1, 1)")
    public void setBoard(BoardDto boardDto);
}
