package com.example.multiple.mappers;


import com.example.multiple.dto.ConfigDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ConfigMapper {

    @Select("SELECT COUNT(*) FROM config WHERE config_code = #{configCode}")
    int getCheckConfigCode(String configCode);

    @Insert("INSERT INTO config VALUES(NULL, #{configCode}, #{configTitle}, #{configComment}, #{configColor}, NOW())")
    void setConfig(ConfigDto configDto);

    @Select("SELECT * FROM config ORDER BY config_id DESC")
    List<ConfigDto> getConfigList();

    @Update("UPDATE config SET config_color = #{color} WHERE config_id = #{id}")
    void getColorChange(int id, String color);

}
