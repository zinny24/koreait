package com.example.multiple.mappers;


import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ConfigMapper {

    @Select("SELECT COUNT(*) FROM config WHERE config_code = #{configCode}")
    int getCheckConfigCode(String configCode);

}
