package com.example.multiple.service;


import com.example.multiple.mappers.ConfigMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConfigService {

    @Autowired
    ConfigMapper configMapper;

    public int getCheckConfigCode(String configCode) { //controller
        return configMapper.getCheckConfigCode(configCode); //mapper
    }

}






