package com.example.multiple;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipleApplicationTests {

	@Test
	void contextLoads() {
	}

}
