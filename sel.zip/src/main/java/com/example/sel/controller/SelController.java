package com.example.sel.controller;

import com.example.sel.dto.DeptDto;
import com.example.sel.mappers.DeptMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
public class SelController {

    @Autowired
    DeptMapper deptMapper;

    @GetMapping("/dept/sel")
    public String getDept() {
        return "dept/sel";
    }

    @PostMapping("/dept/sel")
    @ResponseBody
    public Map<String, Object> setDept() {

        Map<String, Object> map = new HashMap<>();
        map.put("dept", deptMapper.getDeptAll());

        return map;
    }

    @PostMapping("/dept/addDept")
    @ResponseBody
    public Map<String, Object> addDept(@ModelAttribute DeptDto deptDto) {

        Map<String, Object> map = new HashMap<>();
        if( deptDto != null ) {
            deptMapper.addDept(deptDto);
            map.put("message", "ok");
        }

        return map;
    }

    @GetMapping("/dept/multi")
    public String getMulti() {
        return "dept/multiple";
    }

}
