package com.example.chk.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Controller
public class ItemController {

    @GetMapping("/items")
    public String getItem() {
        return "items";
    }

    @PostMapping("/cart")
    public String getCart(@RequestParam List<String> checkedValue) {
        for (String c : checkedValue) {
            System.out.println(c);
        }
        return "items";
    }

}
