package com.example.crud.dto;


import lombok.Data;

@Data
public class CrudDto {
    private int mId;
    private String mUid;
    private String mPWD;
    private String mName;
}
