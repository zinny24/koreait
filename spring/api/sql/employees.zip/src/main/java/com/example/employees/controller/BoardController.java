package com.example.employees.controller;


import com.example.employees.dto.BoardDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/admin/board")
public class BoardController {

    @Value("${spring.servlet.multipart.location}")
    String UPLOAD_LOCATION;

    @GetMapping("")
    public String getBoardList() {
        return "board/list";
    }

    @GetMapping("/write")
    public String getBoardWrite() {
        return "board/write";
    }

    @PostMapping("/write")
    @ResponseBody
    public String setBoardWrite(
            @ModelAttribute BoardDto boardDto,
            MultipartFile uploadFile) {
        //원본파일 이름, 원본파일 용량, 원본파일 이름 바꾸기(날짜로 )
        System.out.println("원본파일명 : " + uploadFile.getOriginalFilename());
        System.out.println("원본파일용량 : " + uploadFile.getSize() + "bytes");

        String oName = uploadFile.getOriginalFilename();
        String ext  = oName.substring(oName.lastIndexOf("."));
        System.out.println("원본파일확장자 : " + ext);

        String tName = System.currentTimeMillis() + ext;
        System.out.println("변환된파일명 : " + tName);

        return "";
    }

}
