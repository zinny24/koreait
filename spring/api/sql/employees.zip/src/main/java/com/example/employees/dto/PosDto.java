package com.example.employees.dto;


import lombok.Data;

@Data
public class PosDto {
    private String korPosCode;
    private String korPosName;
    private String korDeptCode;
}
