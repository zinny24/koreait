package com.example.kor.controller;

import com.example.kor.mapper.ConfigMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ArticleController {

    @Autowired
    private ConfigMapper configMapper;

    @GetMapping("/article/list")
    public String getList(@RequestParam String code, Model model) {
        model.addAttribute("config", configMapper.getConfigOne(code));
        return "article/list";
    }

    @GetMapping("/article/write")
    public String getWrite() {
        return "article/write";
    }

}
