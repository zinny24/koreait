package com.example.kor.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ConfigController {

    @GetMapping("/config")
    public String getConfig() {
        return "config";
    }

    @GetMapping("/create")
    public String getCreate() {
        return "create";
    }

}
