package com.example.kor.mapper;

import com.example.kor.dto.BoardDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface BoardMapper {

    @Insert("INSERT INTO board VALUES(NULL, #{subject}, #{writer}, 1, 1)")
    void setBoardWrite(BoardDto boardDto);

    @Select("SELECT * FROM board ORDER BY id DESC")
    List<BoardDto> getBoardList();

    @Select("SELECT * FROM board WHERE id = #{id}")
    BoardDto getView(int id);
}
