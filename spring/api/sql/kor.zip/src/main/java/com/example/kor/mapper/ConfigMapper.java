package com.example.kor.mapper;

import com.example.kor.dto.ConfigDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ConfigMapper {

    @Insert("INSERT INTO config VALUES( #{code}, #{title}, #{color} )")
    void setConfig(ConfigDto config);

    @Select("create table kortb_${code}(\n" +
            "id int not null auto_increment,\n" +
            "subject varchar(100),\n" +
            "writer varchar(20),\n" +
            "content text,\n" +
            "grp int,\n" +
            "depth int,\n" +
            "primary key(id)\n" +
            ");")
    void createTable(String code);
}
