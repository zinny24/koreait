package com.example.kor.mapper;


import com.example.kor.dto.RegisterDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RegisterMapper {

    @Insert("INSERT INTO member VALUES(NULL, #{userid}, #{username}, #{passwd} , #{level} )" )
    void getRegister(RegisterDto registerDto);

}
