package com.example.kor.service;

import org.springframework.stereotype.Service;

@Service
public class ArticleSrv {
}
