use kordb;

-- 게시판 환경 설정 테이블
create table config(
code varchar(10),
title varchar(100),
color varchar(10),
primary key(code)
);

-- 게시판 테이블 : kor_이름
create table kor_코드이름(
id int not null auto_increment,
subject varchar(100),
writer varchar(20),
content text,
primary key(id)
);









