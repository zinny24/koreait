package com.example.tut00;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut00Application {

	public static void main(String[] args) {
		SpringApplication.run(Tut00Application.class, args);
	}

}
