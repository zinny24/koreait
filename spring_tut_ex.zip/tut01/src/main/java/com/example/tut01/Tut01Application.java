package com.example.tut01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut01Application {

	public static void main(String[] args) {
		SpringApplication.run(Tut01Application.class, args);
	}

}
