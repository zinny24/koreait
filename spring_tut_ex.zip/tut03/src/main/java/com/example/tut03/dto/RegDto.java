package com.example.tut03.dto;


import lombok.Data;

@Data
public class RegDto {
    //필드
    private String email;
    private String passwd;
}










