package com.example.tut03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tut03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
