package com.example.tut04.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class RegDto {
    private String email;
    private String passwd;

}
