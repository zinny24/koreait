package com.example.uploads;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class UploadController {

    @GetMapping("/upload")
    public String getUploads() {
        return "uploadForm";
    }

    @PostMapping("/upload")
    @ResponseBody
    public String setUploads(@RequestParam String username, @RequestParam("file") MultipartFile mf) {
        System.out.println(username);
        System.out.println(mf.getOriginalFilename());
        return "";
    }

    @GetMapping("/uploadAjax")
    public String getUploadAjax() {
        return "uploadAjax";
    }

    @PostMapping("/uploadAjax")
    @ResponseBody
    public String setUploadAjax(@RequestParam String username, @RequestParam("file") MultipartFile mf, String[] hobby) {
        System.out.println("----------데이터------------");
        System.out.println(username);

        System.out.println("----------첨부파일------------");
        System.out.println(mf.getOriginalFilename());

        System.out.println("----------체크박스배열------------");
        for(String h : hobby) {
            System.out.println(h);
        }

        return "uploadAjax";
    }

    @GetMapping("/uploadAjaxEach")
    public String getUploadAjaxEach() {
        return "uploadAjaxEach";
    }

    @PostMapping("/uploadAjaxEach")
    @ResponseBody
    public String setUploadAjaxEach(@RequestParam String username, @RequestParam("file") MultipartFile[] mf, String[] hobby) {
        System.out.println("----------데이터------------");
        System.out.println(username);

        System.out.println("----------첨부파일 각각------------");
        for(MultipartFile file : mf) {
            System.out.println(file.getOriginalFilename());
        }

        System.out.println("----------체크박스배열------------");
        for(String h : hobby) {
            System.out.println(h);
        }

        return "uploadAjax";
    }

}
